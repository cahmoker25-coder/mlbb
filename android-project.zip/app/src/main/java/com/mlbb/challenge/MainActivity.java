package com.mlbb.challenge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class MainActivity extends Activity {
    private WebView web;
    private String home;
    private String homeHost;
    private ImageView splash;
    private boolean splashGone = false;

    private void hideSplash() {
        if (splashGone || splash == null) return;
        splashGone = true;
        splash.animate().alpha(0f).setDuration(300).withEndAction(() -> splash.setVisibility(View.GONE)).start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        home = BuildConfig.START_URL;
        homeHost = Uri.parse(home).getHost();

        web = new WebView(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#FFF8E6"));
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        splash = new ImageView(this);
        splash.setBackgroundColor(Color.parseColor("#FFF8E6"));
        splash.setImageResource(R.drawable.ic_launcher_foreground);
        splash.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int pad = (int) (72 * getResources().getDisplayMetrics().density);
        splash.setPadding(pad, pad, pad, pad);
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        setContentView(root);
        new Handler().postDelayed(this::hideSplash, 8000);   // jaga-jaga kalau koneksi lambat

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);        // localStorage dipakai aplikasi untuk menyimpan pengaturan & statistik
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                hideSplash();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String host = u.getHost();
                if (host != null && host.equals(homeHost)) return false;   // halaman sendiri: tetap di dalam aplikasi
                try {                                                        // link luar (mis. Sociabuzz): buka di browser
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) {
                    // abaikan
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                        + "<body style='font-family:sans-serif;background:#fff8e6;color:#16120e;text-align:center;padding:60px 24px'>"
                        + "<h2>Tidak bisa terhubung</h2><p>Cek koneksi internet lalu coba lagi.</p>"
                        + "<p><a href='" + home + "' style='display:inline-block;padding:14px 26px;border:3px solid #16120e;"
                        + "border-radius:12px;background:#ffc21a;color:#16120e;font-weight:bold;text-decoration:none'>COBA LAGI</a></p>"
                        + "</body></html>";
                    view.loadDataWithBaseURL(home, html, "text/html", "utf-8", null);
                }
            }
        });

        // alert / confirm / prompt dari halaman web WAJIB ditangani di sini, kalau tidak confirm() selalu dianggap "batal"
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setNegativeButton("Batal", (d, w) -> result.cancel())
                    .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, final JsPromptResult result) {
                final EditText input = new EditText(MainActivity.this);
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                if (defaultValue != null) input.setText(defaultValue);
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setView(input)
                    .setCancelable(false)
                    .setPositiveButton("OK", (d, w) -> result.confirm(input.getText().toString()))
                    .setNegativeButton("Batal", (d, w) -> result.cancel())
                    .show();
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(home);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }
}
